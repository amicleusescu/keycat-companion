# KeyCat Companion

## Overview
KeyCat Companion turns everyday keyboard activity into a cozy collection game. Each key press earns one point, and 1,000 points can be spent on a rarity-weighted RNG chest containing a cat skin or accessory.

## Audience
Designed for people who spend time typing and want a playful, low-distraction companion that rewards steady activity.

## Core experience
- Watch an animated cat react to keyboard taps.
- Build a locally saved point balance.
- Spend 1,000 points on a chest with Common 55%, Rare 30%, Epic 12%, and Legendary 3% odds.
- Collect 20 skins and 12 accessories, enabling 240 visual combinations.
- Equip discovered cosmetics from a compact wardrobe; duplicate rewards remain possible.
- Hear a short arcade chime when a chest opens, with a persistent mute control.
- Watch a dedicated animated chest-opening sequence before each reward reveal.
- Preview locked or unlocked cosmetics on the cat before equipping.
- Review recent chest drops with clear new-versus-duplicate labels.
- Use the included .NET 8 WebView2 Windows host for global key counting after explicit consent; only anonymous increment events reach the web UI.
- Enable launch on startup from the native consent screen or tray menu after installing the MSIX package.
- Receive signed Windows updates automatically through the generated App Installer feed.
- Download the latest signed Windows installer directly from the GitHub release.

## Windows host
The `windows-host` project embeds the deployed KeyCat app in WebView2, installs a low-level Windows keyboard hook only after the user approves the native consent dialog, ignores held-key repeats, and keeps no key values or typed text. Closing the window minimizes it to the system tray, where counting can be paused, resumed, or fully stopped.

To build externally on Windows, install the .NET 8 SDK, WebView2 Runtime, and Windows 10/11 SDK. Replace `appUrl` in `windows-host/appsettings.json` with the deployed KeyCat HTTPS URL. Set `KEYCAT_PFX_PATH`, `KEYCAT_PFX_PASSWORD`, and `KEYCAT_RELEASE_BASE_URL`; ensure the certificate subject matches the manifest publisher (`CN=KeyCat` by default); then run `windows-host/build-signed-msix.ps1`. The script advances the persisted four-part release version, publishes the self-contained x64 host, generates custom KeyCat package/tray artwork, packs and signs a versioned MSIX, and emits `KeyCat.Companion.appinstaller`.
Release versions default to build increments. Use `-Bump minor`, `-Bump major`, or `-Version 2.1.0.0` when invoking the script to control the next release. Use `-Bump none` to rebuild the current version without changing `windows-host/release-version.json`. The editable source artwork is stored in `windows-host/keycat-icon.svg`.
The repository is configured for `amicleusescu/keycat-companion` with a GitHub Actions release workflow. Its protected `windows-release` environment reads the signing certificate from `KEYCAT_PFX_BASE64` and `KEYCAT_PFX_PASSWORD`, builds a signed release, and publishes the MSIX plus App Installer feed. Browser buttons target `https://github.com/amicleusescu/keycat-companion/releases/latest/download/KeyCat.Companion.appinstaller` by default; `VITE_KEYCAT_WINDOWS_DOWNLOAD_URL` can override this location.

## Design direction
A cozy night arcade aesthetic with deep ink-blue surfaces, coral controls, moon-gold accents, soft glows, star details, rounded controls, and expressive but restrained character animation. The interface remains focused and easy to scan on desktop and mobile.
