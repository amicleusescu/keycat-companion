## Summary

Describe the KeyCat change and its user impact.

## Validation

- [ ] `validate_project` passes
- [ ] Windows host changes were reviewed on Windows
- [ ] No signing credentials or user key data are committed
