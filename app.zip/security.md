# Security

Report security issues privately to the repository owner rather than opening a public issue with sensitive details.

KeyCat counts keyboard press events only. The Windows host does not retain key values, typed text, or application context. Signing certificates and passwords must remain in the protected `windows-release` GitHub environment and must never be committed.
