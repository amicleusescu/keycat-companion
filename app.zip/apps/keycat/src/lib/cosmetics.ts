export type CosmeticType = 'skin' | 'accessory';
export type Rarity = 'Common' | 'Rare' | 'Epic' | 'Legendary';

export type Cosmetic = {
  id: string;
  name: string;
  type: CosmeticType;
  description: string;
  rarity: Rarity;
  style: number;
};

const skinNames = ['Moon Cream', 'Midnight Ink', 'Coral Comet', 'Golden Hour', 'Lavender Dream', 'Mint Nebula', 'Blueberry Jam', 'Rose Quartz', 'Cocoa Cloud', 'Silver Pixel', 'Peach Soda', 'Aurora Moss', 'Cherry Cola', 'Cloud Nine', 'Arcade Plum', 'Honey Toast', 'Ocean Static', 'Starry Slate', 'Vanilla Byte', 'Cosmic Teal'];
const accessoryNames = ['No Accessory', 'Berry Bow', 'Focus Glasses', 'Tiny Crown', 'Moon Beret', 'Pixel Headphones', 'Star Antenna', 'Cloud Scarf', 'Hero Mask', 'Sleepy Cap', 'Lucky Bell', 'Comet Visor'];

function rarityFor(index: number, total: number): Rarity {
  const ratio = index / total;
  if (ratio >= 0.97) return 'Legendary';
  if (ratio >= 0.85) return 'Epic';
  if (ratio >= 0.55) return 'Rare';
  return 'Common';
}

const skins: Cosmetic[] = skinNames.map((name: string, index: number) => ({
  id: `skin-${index}`,
  name,
  type: 'skin',
  description: `A ${name.toLowerCase()} coat from the night arcade.`,
  rarity: rarityFor(index, skinNames.length),
  style: index,
}));

const accessories: Cosmetic[] = accessoryNames.map((name: string, index: number) => ({
  id: index === 0 ? 'none' : `accessory-${index}`,
  name,
  type: 'accessory',
  description: index === 0 ? 'A clean, classic look.' : `${name} for late-night typing quests.`,
  rarity: rarityFor(index, accessoryNames.length),
  style: index,
}));

export const cosmetics: Cosmetic[] = [...skins, ...accessories];
export const starterIds = ['skin-0', 'none'];
export const combinationCount = skins.length * accessories.length;
export const rarityOdds: Record<Rarity, number> = { Common: 55, Rare: 30, Epic: 12, Legendary: 3 };

export function getCosmetic(id: string): Cosmetic | undefined {
  return cosmetics.find((item: Cosmetic) => item.id === id);
}
