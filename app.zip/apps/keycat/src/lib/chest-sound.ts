type AudioWindow = Window & typeof globalThis & { webkitAudioContext?: typeof AudioContext };

export function playChestSound(): void {
  const AudioContextClass = window.AudioContext ?? (window as AudioWindow).webkitAudioContext;
  if (!AudioContextClass) return;
  const context = new AudioContextClass();
  const now = context.currentTime;
  const notes = [261.63, 329.63, 392, 523.25];

  notes.forEach((frequency: number, index: number) => {
    const oscillator = context.createOscillator();
    const gain = context.createGain();
    const start = now + index * 0.11;
    oscillator.type = index === notes.length - 1 ? 'sine' : 'triangle';
    oscillator.frequency.setValueAtTime(frequency, start);
    oscillator.frequency.exponentialRampToValueAtTime(frequency * 1.025, start + 0.18);
    gain.gain.setValueAtTime(0.0001, start);
    gain.gain.exponentialRampToValueAtTime(0.14, start + 0.025);
    gain.gain.exponentialRampToValueAtTime(0.0001, start + 0.28);
    oscillator.connect(gain);
    gain.connect(context.destination);
    oscillator.start(start);
    oscillator.stop(start + 0.3);
  });

  window.setTimeout(() => void context.close(), 900);
}
