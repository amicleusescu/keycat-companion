export type DesktopBridgeStatus = 'web-only' | 'permission-required' | 'connected';

type KeycatDesktopBridge = {
  getStatus: () => Promise<DesktopBridgeStatus>;
  requestGlobalKeyPermission: () => Promise<boolean>;
  subscribeToKeyPresses: (listener: () => void) => () => void;
};

declare global {
  interface Window {
    keycatDesktop?: KeycatDesktopBridge;
  }
}

export function getDesktopBridge(): KeycatDesktopBridge | undefined {
  return window.keycatDesktop;
}
