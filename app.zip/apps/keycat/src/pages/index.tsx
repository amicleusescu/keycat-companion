import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'motion/react';
import { Check, Download, Eye, History, Keyboard, LockKeyhole, Monitor, Sparkles, Trophy, Volume2, VolumeX } from 'lucide-react';
import { toast } from 'sonner';
import { CatAvatar } from '@/components/cat-avatar';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { playChestSound } from '@/lib/chest-sound';
import { combinationCount, cosmetics, getCosmetic, rarityOdds, type Cosmetic, type Rarity } from '@/lib/cosmetics';
import { useKeycat } from '@/hooks/use-keycat';

const rarityBorder: Record<Rarity, string> = { Common: 'border-l-muted-foreground', Rare: 'border-l-chart-4', Epic: 'border-l-chart-3', Legendary: 'border-l-accent' };
const soundKey = 'keycat-sound-muted';
const githubRepositoryUrl = 'https://github.com/amicleusescu/keycat-companion';
const downloadUrl = import.meta.env.VITE_KEYCAT_WINDOWS_DOWNLOAD_URL ?? `${githubRepositoryUrl}/releases/latest/download/KeyCat.Companion.appinstaller`;

export default function HomePage() {
  const { points, lifetimeKeys, unlocked, equippedSkin, equippedAccessory, dropHistory, lastKey, reward, setReward, equip, openChest, desktopStatus, requestDesktopPermission } = useKeycat();
  const [reacting, setReacting] = useState(false);
  const [preview, setPreview] = useState<Cosmetic | null>(null);
  const [muted, setMuted] = useState(() => localStorage.getItem(soundKey) === 'true');
  const [opening, setOpening] = useState(false);
  const progress = Math.min(100, (points / 1000) * 100);
  const previewSkin = preview?.type === 'skin' ? preview.id : equippedSkin;
  const previewAccessory = preview?.type === 'accessory' ? preview.id : equippedAccessory;

  useEffect(() => {
    if (!lastKey) return;
    setReacting(true);
    const timeout = window.setTimeout(() => setReacting(false), 330);
    return () => window.clearTimeout(timeout);
  }, [lastKey, lifetimeKeys]);

  const toggleSound = () => {
    setMuted((current: boolean) => {
      localStorage.setItem(soundKey, String(!current));
      return !current;
    });
  };

  const handleOpenChest = () => {
    if (points < 1000 || opening) { toast.info('Keep typing — you need 1,000 points.'); return; }
    setOpening(true);
    if (!muted) playChestSound();
    window.setTimeout(() => {
      const item = openChest();
      setOpening(false);
      if (item) toast.success(`${item.rarity}: ${item.name}!`);
    }, 1300);
  };

  const renderCosmetics = (type: Cosmetic['type']) => (
    <div className="grid max-h-[310px] gap-2 overflow-y-auto pr-1 sm:grid-cols-2">
      {cosmetics.filter((item: Cosmetic) => item.type === type).map((item: Cosmetic) => {
        const isUnlocked = unlocked.includes(item.id);
        const isEquipped = item.id === equippedSkin || item.id === equippedAccessory;
        return <div key={item.id} className={`flex min-h-20 items-center gap-2 rounded-2xl border border-l-4 ${rarityBorder[item.rarity]} bg-card p-2 text-card-foreground transition hover:bg-secondary`}>
          <button type="button" onClick={() => setPreview(item)} className="grid size-10 shrink-0 place-items-center rounded-xl bg-secondary text-secondary-foreground" aria-label={`Preview ${item.name}`}><Eye className="size-4" /></button>
          <button type="button" disabled={!isUnlocked} onClick={() => equip(item)} className="min-w-0 flex-1 text-left disabled:cursor-not-allowed"><span className="block truncate text-sm font-bold">{item.name}</span><span className="text-xs text-muted-foreground">{item.rarity}</span></button>
          <span className={`grid size-8 place-items-center rounded-lg ${isUnlocked ? 'bg-accent text-accent-foreground' : 'bg-muted text-muted-foreground'}`}>{isUnlocked ? (isEquipped ? <Check className="size-4" /> : <Sparkles className="size-4" />) : <LockKeyhole className="size-4" />}</span>
        </div>;
      })}
    </div>
  );

  return <main className="relative mx-auto flex w-full max-w-7xl flex-1 flex-col gap-5 overflow-hidden p-4 sm:p-7">
    <header className="flex flex-col gap-4 rounded-[2rem] border bg-card p-5 text-card-foreground shadow-2xl sm:flex-row sm:items-center sm:justify-between">
      <div className="flex items-center gap-3"><span className="grid size-12 place-items-center rounded-2xl bg-primary text-primary-foreground"><Keyboard className="size-6" /></span><div><h1 className="text-2xl font-black">KeyCat After Dark</h1><p className="text-sm text-muted-foreground">Your cozy keyboard companion</p></div></div>
      <div className="flex flex-wrap items-center gap-2">{desktopStatus === 'web-only' && <Button asChild><a href={downloadUrl}><Download className="size-4" /> Install Windows app</a></Button>}<Button variant="secondary" size="icon" onClick={toggleSound} aria-label={muted ? 'Unmute sound' : 'Mute sound'}>{muted ? <VolumeX /> : <Volume2 />}</Button><div className="rounded-2xl bg-secondary px-5 py-3 text-secondary-foreground"><p className="text-xs font-bold">NIGHT TOKENS</p><p className="text-2xl font-black tabular-nums">{points.toLocaleString()}</p></div></div>
    </header>

    <Card className="border-2"><CardContent className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between"><div className="flex items-center gap-3"><span className="grid size-10 place-items-center rounded-xl bg-secondary text-secondary-foreground"><Monitor className="size-5" /></span><div><p className="font-bold">Windows desktop connection</p><p className="text-sm text-muted-foreground">{desktopStatus === 'connected' ? 'Global key counting is active.' : desktopStatus === 'permission-required' ? 'Accessibility permission is required.' : 'Web mode counts keys only while this tab is focused. Install the Windows companion for global counting.'}</p></div></div>{desktopStatus === 'permission-required' && <Button onClick={() => void requestDesktopPermission()}>Grant permission</Button>}{desktopStatus === 'web-only' && <Button variant="secondary" asChild><a href={downloadUrl}><Download className="size-4" /> Download latest installer</a></Button>}</CardContent></Card>

    <section className="grid flex-1 gap-5 lg:grid-cols-[1.08fr_.92fr]">
      <Card className="overflow-hidden border-2 shadow-2xl"><CardContent className="relative flex min-h-[520px] flex-col items-center justify-center p-6"><div className="absolute inset-x-6 top-6 flex justify-between"><Badge variant="secondary">LEVEL {Math.floor(lifetimeKeys / 1000) + 1}</Badge><Badge variant="outline">{preview ? `Preview · ${preview.name}` : lastKey ? `Last key · ${lastKey}` : 'Listening…'}</Badge></div><CatAvatar skin={previewSkin} accessory={previewAccessory} reacting={reacting} />{preview ? <div className="flex gap-2"><Button variant="secondary" onClick={() => setPreview(null)}>Exit preview</Button>{unlocked.includes(preview.id) && <Button onClick={() => { equip(preview); setPreview(null); }}>Equip preview</Button>}</div> : <motion.div animate={reacting ? { scale: [1, 1.08, 1] } : {}} className="rounded-full bg-accent px-6 py-3 text-sm font-black text-accent-foreground">{reacting ? '+1 · purrfect!' : desktopStatus === 'connected' ? 'Listening across Windows' : 'Press any key to play'}</motion.div>}<div className="mt-5 flex gap-6 text-center"><div><p className="text-xl font-black">{lifetimeKeys.toLocaleString()}</p><p className="text-xs text-muted-foreground">keys tapped</p></div><div><p className="text-xl font-black">{unlocked.length}</p><p className="text-xs text-muted-foreground">items found</p></div><div><p className="text-xl font-black">{combinationCount}</p><p className="text-xs text-muted-foreground">looks possible</p></div></div></CardContent></Card>

      <div className="flex flex-col gap-5"><Card className="border-2"><CardHeader className="pb-3"><CardTitle className="flex items-center gap-2"><Trophy className="size-5" /> Midnight chest</CardTitle><CardDescription>Spend 1,000 tokens. Duplicates can drop.</CardDescription></CardHeader><CardContent className="space-y-4"><Progress value={progress} /><div className="grid grid-cols-4 gap-2">{(Object.entries(rarityOdds) as [Rarity, number][]).map(([rarity, odds]: [Rarity, number]) => <div key={rarity} className={`rounded-xl border border-l-4 ${rarityBorder[rarity]} bg-muted p-2 text-muted-foreground`}><p className="text-xs font-bold">{rarity}</p><p className="font-black">{odds}%</p></div>)}</div><Button className="w-full" size="lg" disabled={points < 1000 || opening} onClick={handleOpenChest}>{opening ? 'Opening…' : 'Open chest'}</Button></CardContent></Card>
      <Card className="flex-1 border-2"><CardHeader className="pb-3"><CardTitle>Wardrobe vault</CardTitle><CardDescription>Preview, equip, and review drops.</CardDescription></CardHeader><CardContent><Tabs defaultValue="skins"><TabsList className="mb-4 grid w-full grid-cols-3"><TabsTrigger value="skins">Skins</TabsTrigger><TabsTrigger value="accessories">Accessories</TabsTrigger><TabsTrigger value="history">History</TabsTrigger></TabsList><TabsContent value="skins">{renderCosmetics('skin')}</TabsContent><TabsContent value="accessories">{renderCosmetics('accessory')}</TabsContent><TabsContent value="history"><div className="max-h-[310px] space-y-2 overflow-y-auto">{dropHistory.length === 0 ? <div className="rounded-2xl bg-muted p-6 text-center text-muted-foreground"><History className="mx-auto mb-2" />No drops yet.</div> : dropHistory.map((record) => { const item = getCosmetic(record.cosmeticId); return item ? <div key={record.id} className={`flex items-center gap-3 rounded-2xl border border-l-4 ${rarityBorder[item.rarity]} p-3`}><div className="flex-1"><p className="font-bold">{item.name}</p><p className="text-xs text-muted-foreground">{new Date(record.droppedAt).toLocaleString()}</p></div><Badge variant={record.duplicate ? 'secondary' : 'outline'}>{record.duplicate ? 'Duplicate' : 'New'}</Badge></div> : null; })}</div></TabsContent></Tabs></CardContent></Card></div>
    </section>

    <AnimatePresence>{opening && <motion.div className="fixed inset-0 z-50 grid place-items-center bg-background/95" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}><motion.div animate={{ y: [0, -8, 0], rotate: [0, -4, 4, -2, 2, 0], scale: [1, 1.06, 1] }} transition={{ duration: 0.65, repeat: 1 }} className="relative grid size-48 place-items-center rounded-[2.5rem] border-2 bg-card shadow-2xl"><Trophy className="size-20 text-accent-foreground" /><motion.div className="absolute inset-0 rounded-[2.5rem] border-4 border-primary" animate={{ scale: [1, 1.35], opacity: [1, 0] }} transition={{ duration: 0.7, repeat: 1 }} /><p className="absolute -bottom-12 font-black">Unlocking starlight…</p></motion.div></motion.div>}{reward && !opening && <motion.div className="fixed inset-0 z-50 grid place-items-center bg-background/95 p-4" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}><motion.div className={`w-full max-w-sm rounded-[2rem] border border-l-8 ${rarityBorder[reward.rarity]} bg-card p-8 text-center`} initial={{ scale: 0.7 }} animate={{ scale: 1 }}><Sparkles className="mx-auto mb-4 size-16" /><Badge>{reward.rarity}</Badge><h2 className="mt-3 text-3xl font-black">{reward.name}</h2><Button className="mt-6 w-full" onClick={() => { equip(reward); setReward(null); }}>Equip now</Button><Button variant="ghost" className="mt-2 w-full" onClick={() => setReward(null)}>Keep in vault</Button></motion.div></motion.div>}</AnimatePresence>
  </main>;
}
