import { motion } from 'motion/react';
import { getCosmetic } from '@/lib/cosmetics';

type CatAvatarProps = { skin: string; accessory: string; reacting?: boolean };

const skinFill = ['fill-secondary', 'fill-foreground', 'fill-primary', 'fill-accent', 'fill-chart-3', 'fill-chart-5', 'fill-chart-4'];

export function CatAvatar({ skin, accessory, reacting = false }: CatAvatarProps) {
  const skinItem = getCosmetic(skin);
  const accessoryItem = getCosmetic(accessory);
  const skinStyle = skinItem?.style ?? 0;
  const accessoryStyle = accessoryItem?.style ?? 0;
  const coat = skinFill[skinStyle % skinFill.length];

  return (
    <motion.div className="relative mx-auto aspect-square w-full max-w-[360px]" animate={reacting ? { y: [0, -10, 0], rotate: [0, -1.5, 1.5, 0] } : { y: [0, -4, 0] }} transition={{ duration: reacting ? 0.32 : 3.4, repeat: reacting ? 0 : Infinity, ease: 'easeInOut' as const }} aria-label="Your animated cat companion">
      <div className="absolute inset-10 rounded-full bg-secondary blur-3xl" aria-hidden="true" />
      <svg viewBox="0 0 320 320" role="img" className="relative h-full w-full drop-shadow-2xl">
        <ellipse cx="160" cy="282" rx="104" ry="18" className="fill-muted" />
        <path d="M88 132 70 49l68 47M232 132l18-83-68 47" className={`${coat} stroke-foreground`} strokeWidth="10" strokeLinejoin="round" />
        <path d="M72 165c0-73 39-114 88-114s88 41 88 114v47c0 62-40 82-88 82s-88-20-88-82z" className={`${coat} stroke-foreground`} strokeWidth="10" />
        {skinStyle % 3 === 1 && <path d="M91 110c17-28 41-31 52-9 5 10-4 31-25 44-18 11-39-9-27-35Zm111 82c23-12 43-1 40 19-4 25-29 40-48 24-14-11-8-35 8-43Z" className="fill-accent" />}
        {skinStyle % 3 === 2 && <path d="M119 66q41 29 82 0M102 91q58 34 116 0" fill="none" className="stroke-primary-foreground" strokeWidth="8" strokeLinecap="round" />}
        <path d="M108 164q16 13 32 0M180 164q16 13 32 0" fill="none" className="stroke-foreground" strokeWidth="9" strokeLinecap="round" />
        <path d="m151 190 9 7 9-7M160 198v11m0 0q-16 12-27 0m27 0q16 12 27 0" fill="none" className="stroke-foreground" strokeWidth="6" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M103 194 42 181m61 31-65 8m179-26 61-13m-61 31 65 8" fill="none" className="stroke-foreground" strokeWidth="5" strokeLinecap="round" />
        {accessoryStyle === 1 && <g><path d="M158 243c-28-22-50-16-47 8 4 23 28 22 49 7 21 15 45 16 49-7 3-24-19-30-47-8" className="fill-primary stroke-foreground" strokeWidth="6" /><circle cx="160" cy="251" r="13" className="fill-accent stroke-foreground" strokeWidth="5" /></g>}
        {accessoryStyle === 2 && <g fill="none" className="stroke-foreground" strokeWidth="7"><circle cx="124" cy="166" r="29" /><circle cx="196" cy="166" r="29" /><path d="M153 166h14M95 160l-22-8m152 8 22-8" /></g>}
        {accessoryStyle === 3 && <path d="m112 75 10-48 38 32 38-32 10 48z" className="fill-accent stroke-foreground" strokeWidth="7" strokeLinejoin="round" />}
        {accessoryStyle === 4 && <path d="M104 91q10-61 66-61 44 0 60 42-42-12-126 19Z" className="fill-primary stroke-foreground" strokeWidth="7" />}
        {accessoryStyle === 5 && <g className="stroke-foreground" strokeWidth="8" fill="none"><path d="M83 161q-5-79 77-79t77 79"/><rect x="70" y="145" width="27" height="55" rx="12" className="fill-primary"/><rect x="223" y="145" width="27" height="55" rx="12" className="fill-primary"/></g>}
        {accessoryStyle >= 6 && <g><path d="M160 78V35" className="stroke-foreground" strokeWidth="7"/><path d="m160 20 8 15 17 3-12 12 3 17-16-8-16 8 3-17-12-12 17-3z" className="fill-accent stroke-foreground" strokeWidth="5" /></g>}
      </svg>
    </motion.div>
  );
}
