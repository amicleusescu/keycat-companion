import { useCallback, useEffect, useMemo, useState } from 'react';
import { cosmetics, rarityOdds, starterIds, type Cosmetic, type Rarity } from '@/lib/cosmetics';
import { getDesktopBridge, type DesktopBridgeStatus } from '@/lib/desktop-bridge';

export type DropRecord = {
  id: string;
  cosmeticId: string;
  droppedAt: string;
  duplicate: boolean;
};

const storageKey = 'keycat-progress-v1';

type SavedState = {
  points: number;
  lifetimeKeys: number;
  unlocked: string[];
  equippedSkin: string;
  equippedAccessory: string;
  dropHistory: DropRecord[];
};

const initialState: SavedState = {
  points: 0,
  lifetimeKeys: 0,
  unlocked: starterIds,
  equippedSkin: 'skin-0',
  equippedAccessory: 'none',
  dropHistory: [],
};

function loadState(): SavedState {
  try {
    const saved = localStorage.getItem(storageKey);
    if (!saved) return initialState;
    const parsed = JSON.parse(saved) as Partial<SavedState>;
    return {
      points: Math.max(0, parsed.points ?? 0),
      lifetimeKeys: Math.max(0, parsed.lifetimeKeys ?? 0),
      unlocked: parsed.unlocked?.length ? Array.from(new Set([...starterIds, ...parsed.unlocked])) : starterIds,
      equippedSkin: parsed.equippedSkin?.startsWith('skin-') ? parsed.equippedSkin : 'skin-0',
      equippedAccessory: parsed.equippedAccessory?.startsWith('accessory-') || parsed.equippedAccessory === 'none' ? parsed.equippedAccessory : 'none',
      dropHistory: parsed.dropHistory?.slice(0, 20) ?? [],
    };
  } catch {
    return initialState;
  }
}

export function useKeycat() {
  const [state, setState] = useState<SavedState>(loadState);
  const [lastKey, setLastKey] = useState('');
  const [reward, setReward] = useState<Cosmetic | null>(null);
  const [desktopStatus, setDesktopStatus] = useState<DesktopBridgeStatus>('web-only');

  const addPoint = useCallback((keyLabel: string) => {
    setLastKey(keyLabel);
    setState((current: SavedState) => ({ ...current, points: current.points + 1, lifetimeKeys: current.lifetimeKeys + 1 }));
  }, []);

  useEffect(() => {
    localStorage.setItem(storageKey, JSON.stringify(state));
  }, [state]);

  useEffect(() => {
    const bridge = getDesktopBridge();
    if (bridge) {
      void bridge.getStatus().then((status: DesktopBridgeStatus) => setDesktopStatus(status));
      return bridge.subscribeToKeyPresses(() => addPoint('Global'));
    }
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.repeat || event.metaKey || event.ctrlKey || event.altKey) return;
      addPoint(event.key === ' ' ? 'Space' : event.key);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [addPoint]);

  const requestDesktopPermission = useCallback(async (): Promise<void> => {
    const bridge = getDesktopBridge();
    if (!bridge) return;
    const granted = await bridge.requestGlobalKeyPermission();
    setDesktopStatus(granted ? 'connected' : 'permission-required');
  }, []);

  const equip = useCallback((item: Cosmetic) => {
    if (!state.unlocked.includes(item.id)) return;
    setState((current: SavedState) => ({
      ...current,
      ...(item.type === 'skin' ? { equippedSkin: item.id } : { equippedAccessory: item.id }),
    }));
  }, [state.unlocked]);

  const openChest = useCallback((): Cosmetic | null => {
    if (state.points < 1000) return null;
    const roll = Math.random() * 100;
    const rarity: Rarity = roll < rarityOdds.Legendary ? 'Legendary' : roll < rarityOdds.Legendary + rarityOdds.Epic ? 'Epic' : roll < rarityOdds.Legendary + rarityOdds.Epic + rarityOdds.Rare ? 'Rare' : 'Common';
    const pool = cosmetics.filter((item: Cosmetic) => !starterIds.includes(item.id) && item.rarity === rarity);
    const selected = pool[Math.floor(Math.random() * pool.length)];
    if (!selected) return null;
    setState((current: SavedState) => {
      const duplicate = current.unlocked.includes(selected.id);
      const record: DropRecord = { id: `${Date.now()}-${Math.random()}`, cosmeticId: selected.id, droppedAt: new Date().toISOString(), duplicate };
      return {
        ...current,
        points: current.points - 1000,
        unlocked: duplicate ? current.unlocked : [...current.unlocked, selected.id],
        dropHistory: [record, ...current.dropHistory].slice(0, 20),
      };
    });
    setReward(selected);
    return selected;
  }, [state.points]);

  const unlockedCosmetics = useMemo(
    () => cosmetics.filter((item: Cosmetic) => state.unlocked.includes(item.id)),
    [state.unlocked],
  );

  return { ...state, lastKey, reward, setReward, equip, openChest, unlockedCosmetics, desktopStatus, requestDesktopPermission };
}
