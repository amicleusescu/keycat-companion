# KeyCat Companion

KeyCat is a cozy Windows keyboard companion that turns key presses into points, collectible cat skins, accessories, and rarity-weighted chest rewards.

## Download for Windows

Install the latest signed Windows build from this repository's **Releases** page.

- Latest installer: `https://github.com/amicleusescu/keycat-companion/releases/latest/download/KeyCat.Companion.appinstaller`
- All releases: `https://github.com/amicleusescu/keycat-companion/releases`

Opening the `.appinstaller` file installs KeyCat and enables signed automatic updates. Windows may ask you to confirm the installer and the app's explicit global key-counting consent.

## Repository setup

1. Use `amicleusescu/keycat-companion` as the GitHub repository and push this project to its default branch.
3. Create a protected GitHub Actions environment named `windows-release`.
4. Add `KEYCAT_PFX_BASE64` and `KEYCAT_PFX_PASSWORD` as environment secrets. The certificate publisher must match `CN=KeyCat` in the MSIX manifest.
5. Run **Release Windows app** with a four-part version such as `1.0.1.0`, or push a matching tag such as `v1.0.1.0`.

The workflow builds and signs the MSIX, generates the App Installer update feed, and publishes both files to the latest GitHub release.
