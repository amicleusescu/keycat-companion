# Cat Keyboard Companion

## Product direction
- Build a single-page animated desktop-style companion centered on a small customizable cat.
- Use a playful, toy-like visual style with crisp semantic colors, tactile controls, and clear progress feedback.
- Keep the experience simple enough to understand immediately: type, earn points, open chests, and dress the cat.

## Core experience
- Count each non-repeated keyboard keydown as one point while the app tab is focused.
- Ignore held-key repeat events and avoid triggering browser or app shortcuts where appropriate.
- Show the current spendable point balance and progress toward the next 1,000-point chest.
- Let the user spend exactly 1,000 points to open an RNG chest.
- Award one random locked cosmetic per chest, with a clear reveal animation and duplicate protection.
- Disable chest opening when fewer than 1,000 points are available or all cosmetics are unlocked.
- Save points, unlocked cosmetics, and the equipped look in browser storage on the current device.

## Cat companion
- Present a compact animated cat with idle breathing, blinking, ear/tail movement, and a responsive typing reaction.
- Compose the cat from layered visual parts so skins and accessories visibly update the same character.
- Keep animations subtle, readable, and respectful of reduced-motion preferences.

## Customization
- Provide categories for skins and accessories.
- Show unlocked, equipped, and locked states clearly.
- Allow unlocked items to be equipped or removed immediately.
- Include a starter skin and a curated cosmetic pool with visually distinct rewards.

## Chest reveal
- Use a dedicated chest control near the progress meter.
- Show a short opening sequence followed by the item name, category, and preview on the cat.
- Provide clear feedback when points are insufficient and confirmation when the reward is added.

## Page
- Companion studio — cat preview, live point balance, 1,000-point chest progress and opening action, plus a compact customization collection.

## Data and persistence
- No backend, connector, account, or shared data model.
- Store local progress as points, unlocked cosmetic IDs, equipped cosmetic IDs, and app preferences.
- Validate stored data and recover safely to starter defaults if local storage is missing or invalid.

## Accessibility and safeguards
- Make all customization and chest controls keyboard accessible without awarding points for key presses made while interacting with form controls or buttons.
- Add accessible labels, visible focus states, high-contrast theme tokens, and non-color status cues.
- Prevent key auto-repeat from generating points and prevent a single physical press from being counted more than once.

## Boundaries
- Single-device progress only; no login, cloud sync, leaderboard, marketplace, purchases, or social features.
- One page with no navigation chrome.
