using Windows.ApplicationModel;

namespace KeyCat.WindowsHost;

internal static class StartupManager
{
    private const string TaskId = "KeyCatStartup";

    internal static async Task<bool> IsEnabledAsync()
    {
        try
        {
            StartupTask task = await StartupTask.GetAsync(TaskId);
            return task.State is StartupTaskState.Enabled or StartupTaskState.EnabledByPolicy;
        }
        catch (InvalidOperationException)
        {
            return false;
        }
    }

    internal static async Task<bool> SetEnabledAsync(bool enabled)
    {
        try
        {
            StartupTask task = await StartupTask.GetAsync(TaskId);
            if (enabled)
            {
                StartupTaskState state = await task.RequestEnableAsync();
                return state is StartupTaskState.Enabled or StartupTaskState.EnabledByPolicy;
            }

            task.Disable();
            return false;
        }
        catch (InvalidOperationException)
        {
            MessageBox.Show(
                "Launch on startup is available after installing the signed MSIX package.",
                "KeyCat startup",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return false;
        }
    }
}
