param(
  [ValidateSet('build', 'minor', 'major')]
  [string]$Bump = 'build',
  [string]$Version
)

$ErrorActionPreference = 'Stop'
$statePath = Join-Path $PSScriptRoot 'release-version.json'

if ($Version) {
  if ($Version -notmatch '^\d+\.\d+\.\d+\.\d+$') { throw 'Version must use the four-part MSIX format, for example 1.2.3.0.' }
  $parts = $Version.Split('.')
  $state = [ordered]@{ major = [int]$parts[0]; minor = [int]$parts[1]; build = [int]$parts[2] }
} else {
  $state = Get-Content $statePath -Raw | ConvertFrom-Json
  switch ($Bump) {
    'major' { $state.major++; $state.minor = 0; $state.build = 0 }
    'minor' { $state.minor++; $state.build = 0 }
    'build' { $state.build++ }
  }
}

$releaseVersion = "$($state.major).$($state.minor).$($state.build).0"
$state | ConvertTo-Json | Set-Content $statePath -Encoding UTF8
Write-Output $releaseVersion
