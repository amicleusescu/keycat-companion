param([Parameter(Mandatory = $true)][string]$OutputDirectory)

$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
New-Item -ItemType Directory -Path $OutputDirectory -Force | Out-Null

function New-KeyCatBitmap([int]$Size) {
  $bitmap = New-Object System.Drawing.Bitmap($Size, $Size)
  $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
  $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $graphics.Clear([System.Drawing.Color]::FromArgb(30, 29, 61))
  $coral = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(242, 143, 101))
  $gold = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(246, 207, 120))
  $ink = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(30, 29, 61))
  $scale = $Size / 512.0
  $graphics.FillEllipse($coral, 104 * $scale, 118 * $scale, 304 * $scale, 304 * $scale)
  $leftEar = [System.Drawing.PointF[]]@((New-Object System.Drawing.PointF(126 * $scale, 190 * $scale)), (New-Object System.Drawing.PointF(150 * $scale, 55 * $scale)), (New-Object System.Drawing.PointF(242 * $scale, 150 * $scale)))
  $rightEar = [System.Drawing.PointF[]]@((New-Object System.Drawing.PointF(386 * $scale, 190 * $scale)), (New-Object System.Drawing.PointF(362 * $scale, 55 * $scale)), (New-Object System.Drawing.PointF(270 * $scale, 150 * $scale)))
  $graphics.FillPolygon($coral, $leftEar); $graphics.FillPolygon($coral, $rightEar)
  $graphics.FillEllipse($ink, 188 * $scale, 238 * $scale, 34 * $scale, 50 * $scale)
  $graphics.FillEllipse($ink, 290 * $scale, 238 * $scale, 34 * $scale, 50 * $scale)
  $nose = [System.Drawing.PointF[]]@((New-Object System.Drawing.PointF(240 * $scale, 292 * $scale)), (New-Object System.Drawing.PointF(272 * $scale, 292 * $scale)), (New-Object System.Drawing.PointF(256 * $scale, 310 * $scale)))
  $graphics.FillPolygon($ink, $nose)
  $starFont = New-Object System.Drawing.Font('Segoe UI Symbol', [Math]::Max(8, 58 * $scale), [System.Drawing.FontStyle]::Bold)
  $graphics.DrawString('★', $starFont, $gold, 224 * $scale, 342 * $scale)
  $starFont.Dispose(); $coral.Dispose(); $gold.Dispose(); $ink.Dispose(); $graphics.Dispose()
  return $bitmap
}

$assets = @{
  'StoreLogo.png' = 50
  'Square44x44Logo.png' = 44
  'Square150x150Logo.png' = 150
}
foreach ($asset in $assets.GetEnumerator()) {
  $bitmap = New-KeyCatBitmap $asset.Value
  $bitmap.Save((Join-Path $OutputDirectory $asset.Key), [System.Drawing.Imaging.ImageFormat]::Png)
  $bitmap.Dispose()
}

$iconBitmap = New-KeyCatBitmap 256
$icon = [System.Drawing.Icon]::FromHandle($iconBitmap.GetHicon())
$iconStream = [System.IO.File]::Create((Join-Path $OutputDirectory 'keycat.ico'))
$icon.Save($iconStream)
$iconStream.Dispose(); $icon.Dispose(); $iconBitmap.Dispose()
