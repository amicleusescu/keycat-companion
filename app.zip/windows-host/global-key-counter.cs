using System.Diagnostics;
using System.Runtime.InteropServices;

namespace KeyCat.WindowsHost;

internal sealed class GlobalKeyCounter : IDisposable
{
    private const int WhKeyboardLl = 13;
    private const int WmKeyDown = 0x0100;
    private const int WmKeyUp = 0x0101;
    private const int WmSysKeyDown = 0x0104;
    private const int WmSysKeyUp = 0x0105;

    private readonly HashSet<uint> pressedKeys = [];
    private readonly LowLevelKeyboardProc callback;
    private IntPtr hookHandle;

    public event EventHandler? KeyPressed;

    public GlobalKeyCounter()
    {
        callback = HookCallback;
    }

    public bool IsRunning => hookHandle != IntPtr.Zero;

    public void Start()
    {
        if (IsRunning) return;
        using Process process = Process.GetCurrentProcess();
        using ProcessModule? module = process.MainModule;
        IntPtr moduleHandle = GetModuleHandle(module?.ModuleName);
        hookHandle = SetWindowsHookEx(WhKeyboardLl, callback, moduleHandle, 0);
        if (hookHandle == IntPtr.Zero)
        {
            throw new InvalidOperationException("Windows declined the global keyboard hook.");
        }
    }

    public void Stop()
    {
        if (!IsRunning) return;
        UnhookWindowsHookEx(hookHandle);
        hookHandle = IntPtr.Zero;
        pressedKeys.Clear();
    }

    private IntPtr HookCallback(int code, IntPtr message, IntPtr data)
    {
        if (code >= 0)
        {
            uint virtualKey = unchecked((uint)Marshal.ReadInt32(data));
            long kind = message.ToInt64();
            if ((kind == WmKeyDown || kind == WmSysKeyDown) && pressedKeys.Add(virtualKey))
            {
                KeyPressed?.Invoke(this, EventArgs.Empty);
            }
            else if (kind == WmKeyUp || kind == WmSysKeyUp)
            {
                pressedKeys.Remove(virtualKey);
            }
        }
        return CallNextHookEx(hookHandle, code, message, data);
    }

    public void Dispose()
    {
        Stop();
        GC.SuppressFinalize(this);
    }

    private delegate IntPtr LowLevelKeyboardProc(int code, IntPtr message, IntPtr data);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SetWindowsHookEx(int hookId, LowLevelKeyboardProc callback, IntPtr module, uint threadId);

    [DllImport("user32.dll", SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool UnhookWindowsHookEx(IntPtr hook);

    [DllImport("user32.dll")]
    private static extern IntPtr CallNextHookEx(IntPtr hook, int code, IntPtr message, IntPtr data);

    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    private static extern IntPtr GetModuleHandle(string? moduleName);
}
