using System.Text.Json;
using Microsoft.Web.WebView2.Core;
using Microsoft.Web.WebView2.WinForms;

namespace KeyCat.WindowsHost;

internal sealed class MainForm : Form
{
    private const string ConsentSetting = "GlobalCountingConsent";
    private readonly WebView2 webView = new() { Dock = DockStyle.Fill };
    private readonly GlobalKeyCounter keyCounter = new();
    private readonly NotifyIcon trayIcon;
    private bool allowExit;
    private bool consentGranted;

    public MainForm()
    {
        Text = "KeyCat Companion";
        MinimumSize = new Size(960, 680);
        StartPosition = FormStartPosition.CenterScreen;
        Controls.Add(webView);

        ContextMenuStrip trayMenu = new();
        trayMenu.Items.Add("Open KeyCat", null, (_, _) => RestoreWindow());
        trayMenu.Items.Add("Pause global counting", null, (_, _) => SetCounting(false));
        trayMenu.Items.Add("Resume global counting", null, (_, _) => RequestPermission());
        ToolStripMenuItem startupItem = new("Launch when Windows starts") { CheckOnClick = true };
        startupItem.Checked = StartupManager.IsEnabledAsync().GetAwaiter().GetResult();
        startupItem.CheckedChanged += async (_, _) =>
        {
            bool enabled = await StartupManager.SetEnabledAsync(startupItem.Checked);
            startupItem.Checked = enabled;
        };
        trayMenu.Items.Add(startupItem);
        trayMenu.Items.Add(new ToolStripSeparator());
        trayMenu.Items.Add("Exit", null, (_, _) => ExitApplication());
        string iconPath = Path.Combine(AppContext.BaseDirectory, "Assets", "keycat.ico");
        Icon appIcon = File.Exists(iconPath) ? new Icon(iconPath) : SystemIcons.Application;
        Icon = appIcon;
        trayIcon = new NotifyIcon
        {
            Text = "KeyCat Companion",
            Icon = appIcon,
            Visible = true,
            ContextMenuStrip = trayMenu
        };
        trayIcon.DoubleClick += (_, _) => RestoreWindow();

        FormClosing += OnFormClosing;
        Load += async (_, _) => await InitializeWebViewAsync();
        keyCounter.KeyPressed += (_, _) => SendKeyIncrement();
    }

    private async Task InitializeWebViewAsync()
    {
        await webView.EnsureCoreWebView2Async();
        CoreWebView2 core = webView.CoreWebView2;
        core.Settings.AreDevToolsEnabled = false;
        core.Settings.IsStatusBarEnabled = false;
        core.WebMessageReceived += OnWebMessageReceived;
        await core.AddScriptToExecuteOnDocumentCreatedAsync(BridgeScript);
        core.Navigate(ReadAppUrl());
    }

    private void OnWebMessageReceived(object? sender, CoreWebView2WebMessageReceivedEventArgs args)
    {
        try
        {
            using JsonDocument document = JsonDocument.Parse(args.WebMessageAsJson);
            JsonElement root = document.RootElement;
            string type = root.GetProperty("type").GetString() ?? string.Empty;
            string id = root.TryGetProperty("id", out JsonElement idElement) ? idElement.GetString() ?? string.Empty : string.Empty;

            if (type == "getStatus")
            {
                Reply(id, keyCounter.IsRunning ? "connected" : "permission-required");
            }
            else if (type == "requestPermission")
            {
                Reply(id, RequestPermission());
            }
        }
        catch (JsonException)
        {
            // Ignore malformed page messages. No key data is ever accepted or retained.
        }
    }

    private bool RequestPermission()
    {
        if (!consentGranted)
        {
            DialogResult result = MessageBox.Show(
                "Allow KeyCat to count keyboard presses while other Windows apps are active?\n\nOnly anonymous press counts are sent to KeyCat. Key names and typed text are never stored or transmitted. You can pause counting from the tray icon at any time.",
                "Enable global key counting",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Information,
                MessageBoxDefaultButton.Button2);
            consentGranted = result == DialogResult.Yes;
        }

        SetCounting(consentGranted);
        return keyCounter.IsRunning;
    }

    private void SetCounting(bool enabled)
    {
        try
        {
            if (enabled) keyCounter.Start(); else keyCounter.Stop();
            SendStatus();
        }
        catch (InvalidOperationException error)
        {
            MessageBox.Show(error.Message, "KeyCat permission error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            SendStatus();
        }
    }

    private void SendKeyIncrement()
    {
        if (InvokeRequired)
        {
            BeginInvoke(SendKeyIncrement);
            return;
        }
        webView.CoreWebView2?.PostWebMessageAsJson("{\"type\":\"keyPress\"}");
    }

    private void SendStatus()
    {
        if (webView.CoreWebView2 is null) return;
        string status = keyCounter.IsRunning ? "connected" : "permission-required";
        webView.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new { type = "status", status }));
    }

    private void Reply(string id, object value)
    {
        webView.CoreWebView2.PostWebMessageAsJson(JsonSerializer.Serialize(new { type = "response", id, value }));
    }

    private static string ReadAppUrl()
    {
        string path = Path.Combine(AppContext.BaseDirectory, "appsettings.json");
        using JsonDocument settings = JsonDocument.Parse(File.ReadAllText(path));
        return settings.RootElement.GetProperty("appUrl").GetString() ?? "https://localhost";
    }

    private void OnFormClosing(object? sender, FormClosingEventArgs args)
    {
        if (allowExit) return;
        args.Cancel = true;
        Hide();
        trayIcon.ShowBalloonTip(2000, "KeyCat is still counting", "Use the tray icon to pause counting or exit.", ToolTipIcon.Info);
    }

    private void RestoreWindow()
    {
        Show();
        WindowState = FormWindowState.Normal;
        Activate();
    }

    private void ExitApplication()
    {
        allowExit = true;
        keyCounter.Dispose();
        trayIcon.Visible = false;
        trayIcon.Dispose();
        Close();
    }

    private const string BridgeScript = """
(() => {
  const pending = new Map();
  const listeners = new Set();
  let requestNumber = 0;
  const request = (type) => new Promise((resolve) => {
    const id = String(++requestNumber);
    pending.set(id, resolve);
    window.chrome.webview.postMessage({ type, id });
  });
  window.chrome.webview.addEventListener('message', (event) => {
    const message = event.data;
    if (message?.type === 'response') {
      pending.get(message.id)?.(message.value);
      pending.delete(message.id);
    } else if (message?.type === 'keyPress') {
      listeners.forEach((listener) => listener());
    }
  });
  window.keycatDesktop = Object.freeze({
    getStatus: () => request('getStatus'),
    requestGlobalKeyPermission: () => request('requestPermission'),
    subscribeToKeyPresses: (listener) => {
      listeners.add(listener);
      return () => listeners.delete(listener);
    }
  });
})();
""";
}
