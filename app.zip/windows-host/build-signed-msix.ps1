param(
  [ValidateSet('build', 'minor', 'major', 'none')]
  [string]$Bump = 'build',
  [string]$Version
)

$ErrorActionPreference = 'Stop'

if (-not $env:KEYCAT_PFX_PATH) { throw 'Set KEYCAT_PFX_PATH to the signing certificate (.pfx).' }
if (-not $env:KEYCAT_PFX_PASSWORD) { throw 'Set KEYCAT_PFX_PASSWORD to the certificate password.' }
if (-not $env:KEYCAT_RELEASE_BASE_URL) { throw 'Set KEYCAT_RELEASE_BASE_URL to the HTTPS folder where release files will be hosted.' }

$project = Join-Path $PSScriptRoot 'keycat-windows-host.csproj'
$manifestTemplate = Join-Path $PSScriptRoot 'package.appxmanifest'
$publish = Join-Path $PSScriptRoot 'artifacts\publish'
$release = Join-Path $PSScriptRoot 'artifacts\release'
$assets = Join-Path $publish 'Assets'
$versionScript = Join-Path $PSScriptRoot 'new-release-version.ps1'
$assetScript = Join-Path $PSScriptRoot 'generate-package-assets.ps1'

if ($Version) { $releaseVersion = & $versionScript -Version $Version }
elseif ($Bump -eq 'none') {
  $state = Get-Content (Join-Path $PSScriptRoot 'release-version.json') -Raw | ConvertFrom-Json
  $releaseVersion = "$($state.major).$($state.minor).$($state.build).0"
} else { $releaseVersion = & $versionScript -Bump $Bump }

$versionedPackageName = "KeyCat.Companion-$releaseVersion.msix"
$packageName = 'KeyCat.Companion.msix'
$package = Join-Path $release $packageName
$appInstaller = Join-Path $release 'KeyCat.Companion.appinstaller'
$baseUrl = $env:KEYCAT_RELEASE_BASE_URL.TrimEnd('/')

Remove-Item $publish -Recurse -Force -ErrorAction SilentlyContinue
New-Item -ItemType Directory -Path $publish, $release, $assets -Force | Out-Null
& $assetScript -OutputDirectory $assets

dotnet publish $project -c Release -r win-x64 --self-contained true -p:Version=$releaseVersion -o $publish
if ($LASTEXITCODE -ne 0) { throw 'dotnet publish failed.' }

$makeAppx = Get-ChildItem "${env:ProgramFiles(x86)}\Windows Kits\10\bin" -Filter makeappx.exe -Recurse | Sort-Object FullName -Descending | Select-Object -First 1
$signtool = Get-ChildItem "${env:ProgramFiles(x86)}\Windows Kits\10\bin" -Filter signtool.exe -Recurse | Sort-Object FullName -Descending | Select-Object -First 1
if (-not $makeAppx -or -not $signtool) { throw 'Install the Windows 10/11 SDK (MakeAppx and SignTool).' }

$manifest = (Get-Content $manifestTemplate -Raw).Replace('__KEYCAT_VERSION__', $releaseVersion)
$manifest | Set-Content (Join-Path $publish 'AppxManifest.xml') -Encoding UTF8
& $makeAppx.FullName pack /d $publish /p $package /o
if ($LASTEXITCODE -ne 0) { throw 'MSIX packaging failed.' }
& $signtool.FullName sign /fd SHA256 /f $env:KEYCAT_PFX_PATH /p $env:KEYCAT_PFX_PASSWORD $package
if ($LASTEXITCODE -ne 0) { throw 'MSIX signing failed.' }

$appInstallerXml = @"
<?xml version="1.0" encoding="utf-8"?>
<AppInstaller xmlns="http://schemas.microsoft.com/appx/appinstaller/2018" Version="$releaseVersion" Uri="$baseUrl/KeyCat.Companion.appinstaller">
  <MainPackage Name="KeyCat.Companion" Publisher="CN=KeyCat" Version="$releaseVersion" ProcessorArchitecture="x64" Uri="$baseUrl/$packageName" />
  <UpdateSettings>
    <OnLaunch HoursBetweenUpdateChecks="4" ShowPrompt="true" UpdateBlocksActivation="false" />
    <AutomaticBackgroundTask />
    <ForceUpdateFromAnyVersion>false</ForceUpdateFromAnyVersion>
  </UpdateSettings>
</AppInstaller>
"@
$appInstallerXml | Set-Content $appInstaller -Encoding UTF8
Write-Host "Release $releaseVersion created in $release"
Write-Host "Upload $packageName and KeyCat.Companion.appinstaller to $baseUrl"
Write-Host "Versioned release label: $versionedPackageName"
